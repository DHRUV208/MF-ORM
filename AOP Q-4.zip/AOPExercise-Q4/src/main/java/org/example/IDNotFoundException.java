package org.example;

public class IDNotFoundException extends Exception {
    public IDNotFoundException(String s) {
        super(s);
    }
}
